import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Parser {
	 public static void main(String [] args) {
		 	
	       
	    }
}
