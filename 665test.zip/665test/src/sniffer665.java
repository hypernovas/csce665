
import java.util.Random;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


import org.jnetpcap.Pcap;  
import org.jnetpcap.packet.Payload;
import org.jnetpcap.packet.PcapPacket;  
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.PcapPacketHandler;  
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.network.Ip4; 
import org.jnetpcap.nio.JBuffer;  
import org.jnetpcap.nio.JMemory;  

  

public class sniffer665 {  
  
    /** 
     * Main startup method 
     *  arg0
     * @param args 
     *          ignored 
     * @throws IOException 
     */  
	


    public static void main(String[] args) throws IOException {  
        /*************************************************************************** 
         * First we setup error buffer and name for our file 
         **************************************************************************/  
        final StringBuilder errbuf = new StringBuilder(); // For any error msgs  
        final String file = "tfsession.pcap";  
        
        //System.out.println("enter the file name: ");
        //Scanner keyboard = new Scanner(System.in);
       // final String file = keyboard.nextLine();
       
       // File file = new File(filename);
       // Scanner inputFile = new Scanner(file);
        System.out.printf("Opening file for reading: %s%n", file);  
  
        /*************************************************************************
         * Second we open up the selected file using openOffline call 
         **************************************************************************/  
        Pcap pcap = Pcap.openOffline(file, errbuf);  
        if (pcap == null) {  
            System.err.printf("Error while opening device for capture: "  
                + errbuf.toString());  
            return;  
        }  
        //final PrintWriter out = new PrintWriter("telnet.txt");
        //final FileOutputStream out = new FileOutputStream("telnet.txt");
        Random r = new Random();
        final BufferedWriter writer = new BufferedWriter( new FileWriter("telnet"+( r.nextInt((1000 - 1) + 1))+".txt"));
        //System.out.println(writer.toString());
        final BufferedWriter writer2 = new BufferedWriter( new FileWriter("ftp"+( r.nextInt((1000 - 1) + 1))+".txt"));
        final BufferedWriter writer3 = new BufferedWriter( new FileWriter("http"+( r.nextInt((1000 - 1) + 1))+".html"));

        /*************************************************************************** 
         * Third we create a packet handler which will receive packets from the 
         * libpcap loop. 
         **************************************************************************/  
        PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {   
        	StringBuilder output = new StringBuilder();
        	Tcp tcp = new Tcp(); // Preallocate a Tcp header  
        	Ip4 ip = new Ip4();
        	int portNums = 0;
        	int portNumd = 0;
        	int desID=0;
        	int srcID=0;
        	int plen =0;
        	int ses[][] = new int[8][3];
        	int sesCount=0;
            public void nextPacket(PcapPacket packet, String user) {  
            	//System.out.printf("Received at %s caplen=%-4d len=%-4d %s\n",   
                //    new Date(packet.getCaptureHeader().timestampInMillis()),   
                  //  packet.getCaptureHeader().caplen(), // Length actually captured  
                   // packet.getCaptureHeader().wirelen(), // Original length  
                    //packet.getCaptureHeader().
                    //user // User supplied object  
                    //); 
            	
               if (packet.hasHeader(tcp)) { 
               		//byte[] ba = new byte[tcp.getPayloadLength()];
               		//String total = "";
            	   portNumd = tcp.destination();
            	   portNums = tcp.source();
            	   desID = tcp.destination();
            	   srcID = tcp.source();
            	   plen = tcp.size();
            	   if (ses[0][0]==0){
            		   ses[0][1]=desID;
            		   ses[0][2]=srcID;
    				   ses[sesCount][0]=1;
    				   System.out.println("New session"+sesCount);
    				   sesCount++;

            	   }
            	   
            		   if (ses[sesCount][0]==1){
            			   if((portNumd==ses[sesCount][1]&&portNums==ses[sesCount][2])||(portNumd==ses[sesCount][2]&&portNums==ses[sesCount][1])){
            				   System.out.println("New session");
            				   sesCount++;
            				   ses[sesCount][0]=1;

            			   }
            		   }
            	
            	   
            	   if (portNumd==23 || portNums ==23){
            		   	JBuffer storage = new JBuffer(JMemory.Type.POINTER);
            		   	JBuffer payload = tcp.peerPayloadTo(storage);
            		   	
            		   	String hex = payload.toHexdump(packet.size(),false,false,true);
            		  // 	System.out.println("before translation: "+hex);
        		   		hex = hex.replaceAll("\\s+","");
            		   	for (int i = 0; i < hex.length(); i+=2) {
            		   		String str = "";
                 	        str = hex.substring(i, i+2);
                 	     //   System.out.println("temp string is "+str);
                 	        output.append((char)Integer.parseInt(str, 16));
                 	    }
            		  // 	System.out.println("output is ==>"+output);
            		   	try {
							writer.write(output.toString());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
            		   		output.setLength(0);
            	   }else if (portNumd==21 || portNums ==21){   // in case of ftp 
           		   	JBuffer storage = new JBuffer(JMemory.Type.POINTER);
           		   	JBuffer payload = tcp.peerPayloadTo(storage);
           		   	
           		   	String hex = payload.toHexdump(packet.size(),false,false,true);
           		  // 	System.out.println("before translation: "+hex);
       		   		hex = hex.replaceAll("\\s+","");
           		   	for (int i = 0; i < hex.length(); i+=2) {
           		   		String str = "";
                	        str = hex.substring(i, i+2);
                	    //    System.out.println("temp string is "+str);
                	        output.append((char)Integer.parseInt(str, 16));
                	    }
           		//   	System.out.println("output is ==>"+output);
           		   	try {
							writer2.write(output.toString());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
           		   		output.setLength(0);
           		   	//	System.out.println("end of FTP!!!!!!!!!!!!!!!");
           	   } // end of ftp
            	   else if (portNumd==80 || portNums ==80){   // in case of http
              		   	JBuffer storage = new JBuffer(JMemory.Type.POINTER);
              		   	JBuffer payload = tcp.peerPayloadTo(storage);
              		   	String hex = payload.toHexdump(packet.size(),false,false,true);
              		 //  	System.out.println("before translation: "+hex);
          		   		hex = hex.replaceAll("\\s+","");
              		   	for (int i = 0; i < hex.length(); i+=2) {
              		   		String str = "";
                   	        str = hex.substring(i, i+2);
                   	        //System.out.println("temp string is "+str);
                   	        output.append((char)Integer.parseInt(str, 16));
                   	    }
              		 //  	System.out.println("output is ==>"+output);
              		   	try {
   							writer3.write(output.toString());
   						} catch (IOException e) {
   							// TODO Auto-generated catch block
   							e.printStackTrace();
   						}
              		   		output.setLength(0);
              	   } // end of http
               }
            }  
        };  
  
        /*************************************************************************** 
         * Fourth we enter the loop and tell it to capture 10 packets. The loop 
         * method does a mapping of pcap.datalink() DLT value to JProtocol ID, which 
         * is needed by JScanner. The scanner scans the packet buffer and decodes 
         * the headers. The mapping is done automatically, although a variation on 
         * the loop method exists that allows the programmer to sepecify exactly 
         * which protocol ID to use as the data link type for this pcap interface. 
         **************************************************************************/  
        try {  
            pcap.loop(1746, jpacketHandler, "jNetPcap rocks!");  
        } finally {  
        /*************************************************************************** 
         * Last thing to do is close the pcap handle 
         **************************************************************************/  
           pcap.close();  
          writer.close();
          writer2.close();
          writer3.close();
          System.out.println("files generated..");
        }  
    }  
}  