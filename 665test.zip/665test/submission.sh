#!/bin/sh
java -Djava.library.path=/home/yangyong/Downloads/jnetpcap-1.3.0 -jar test2.jar
